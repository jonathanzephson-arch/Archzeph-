# ARCHZEPH Android — prototype hors connexion

## Ce que contient cette version
- Application Android minimale affichant l'interface ARCHZEPH depuis un fichier local.
- L'interface est embarquée dans l'application : Internet n'est pas nécessaire pour l'utiliser une fois installée.
- Pièces 2D simplifiées, meubles symboliques, estimation indicative, prix modifiables et export CSV.
- Workflow GitHub Actions inclus pour compiler un APK de test dans le cloud, depuis un téléphone.

## Limites
- Ce n'est pas encore une application professionnelle complète : pas de vraie vue 3D, pas de comptes ni synchronisation, pas de notifications garanties en arrière-plan.
- Les quantités et prix sont indicatifs et doivent être vérifiés.
- Les calculs de structure destinés à l'exécution doivent être conçus/validés par un ingénieur qualifié.
- Les projets enregistrés dans le stockage local du navigateur peuvent être perdus si les données de l'application sont effacées ou si elle est désinstallée. Exportez vos devis.

## Compiler un APK depuis un téléphone Android (GitHub Actions)
1. Téléchargez puis extrayez l'archive ZIP.
2. Dans votre navigateur, ouvrez https://github.com et créez un compte ou connectez-vous.
3. Créez un nouveau dépôt, par exemple `archzeph-android`. Pour ce premier essai, le dépôt doit être public afin d'utiliser simplement GitHub Actions et les instructions.
4. Sur la page du dépôt, utilisez **Add file > Upload files** et envoyez les fichiers et dossiers contenus dans `archzeph_android`. Assurez-vous que `.github/workflows/android-apk.yml` est présent dans le dépôt (GitHub peut masquer les dossiers commençant par un point dans certains sélecteurs mobiles).
5. Validez avec **Commit changes**.
6. Ouvrez l'onglet **Actions**, sélectionnez **Build ARCHZEPH Android APK**, puis **Run workflow** si nécessaire.
7. Attendez que l'exécution soit terminée avec une coche verte. Ouvrez cette exécution et téléchargez l'artefact `ARCHZEPH-debug-APK`.
8. Extrayez l'archive d'artefact téléchargée, puis ouvrez `app-debug.apk` sur votre Android pour l'installer. Android peut demander d'autoriser l'installation depuis cette source.

Le workflow compile dans le cloud : vous n'avez pas besoin d'installer Android Studio sur le téléphone. La première configuration peut être un peu délicate sur écran mobile.

## Confidentialité et sécurité
Le dépôt public rend le code source visible au public. N'y placez aucun mot de passe, clé privée ni donnée personnelle. L'APK généré est un APK de débogage destiné aux tests, pas une version signée de publication.

## Tester l'interface sans APK
Vous pouvez ouvrir `app/src/main/assets/index.html` dans un navigateur compatible, ou utiliser le fichier HTML fourni séparément.
