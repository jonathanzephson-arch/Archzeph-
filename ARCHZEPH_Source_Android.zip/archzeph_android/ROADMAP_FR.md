# Feuille de route ARCHZEPH

## Version 0.1 — base hors connexion
- [x] Interface mobile locale
- [x] Pièces 2D simplifiées
- [x] Ajout de meubles symboliques
- [x] Première estimation de métrés
- [x] Export de devis CSV
- [x] Conteneur Android WebView sans permission Internet

## Version 0.2 — dessin 2D utile
- [ ] Outils mur, porte, fenêtre avec dimensions réelles
- [ ] Déplacement et accrochage des éléments à la grille
- [ ] Gestion des ouvertures dans les métrés
- [ ] Sauvegarde/export complet du projet JSON
- [ ] PDF imprimable du plan et du devis

## Version 0.3 — vue 3D
- [ ] Géométrie 3D depuis les murs et ouvertures
- [ ] Navigation caméra et matériaux
- [ ] Bibliothèque de meubles

## Version 0.4 — quantitatif et catalogue local
- [ ] Bibliothèque de prix modifiable en FCFA
- [ ] Fondations, élévation, toiture et finitions paramétrables
- [ ] Hypothèses visibles, pertes et main-d'œuvre séparées

## Version 0.5 — calculs techniques
- [ ] Données de charges, matériaux, appuis et normes explicites
- [ ] Vérifications de cohérence et rapports
- [ ] Validation par un ingénieur qualifié avant tout usage d'exécution
